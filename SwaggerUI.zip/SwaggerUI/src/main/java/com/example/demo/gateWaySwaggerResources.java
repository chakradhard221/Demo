package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

@EnableAutoConfiguration
@Primary
@Configuration
public class gateWaySwaggerResources implements SwaggerResourcesProvider {

	@Autowired
	private SwaggerServicesConfig swaggerServiceList;

	@Override
	public List<SwaggerResource> get() {
		// TODO Auto-generated method stub

		ArrayList<SwaggerResource> resources = new ArrayList<SwaggerResource>();
		List<SwaggerServices> listService = swaggerServiceList.getListService();
		for (SwaggerServices swaggerServices : listService) {
			resources.add(
					swaggerResource(swaggerServices.getName(), swaggerServices.getUrl(), swaggerServices.getVersion()));

		}
		return resources;
	}

	private SwaggerResource swaggerResource(String name, String location, String version) {
		SwaggerResource swaggerResource = new SwaggerResource();
		swaggerResource.setName(name);
		swaggerResource.setLocation(location);
		swaggerResource.setSwaggerVersion(version);
		return swaggerResource;
	}

}
