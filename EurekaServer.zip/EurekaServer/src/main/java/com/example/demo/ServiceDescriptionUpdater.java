package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@Primary
//@EnableAutoConfiguration
public class ServiceDescriptionUpdater {
	private static final String DEFAULT_SWAGGER_URL = "/v2/api-docs";
	private static final String KEY_SWAGGER_URL = "swagger-url.html";

	@Autowired
	private DiscoveryClient discoveryClient;

	private final RestTemplate template;

	public ServiceDescriptionUpdater() {
		this.template = new RestTemplate();
	}

	@Autowired
	private ServiceDefinitionsContext definitionContext;

	@Scheduled(fixedDelayString = "5000")
	public void refreshSwaggerConfigurations() throws JsonProcessingException {
		List<String> services = discoveryClient.getServices();
		for (String serviceID : services) {

			ServiceInstance serviceInstance = discoveryClient.getInstances(serviceID).get(0);

			String swaggerURL = getSwaggerURL(serviceInstance);

			Object jsonData = template.getForObject(swaggerURL, Object.class);
			
			if(jsonData!=null){
				String content = getJSON(serviceID, jsonData);
				definitionContext.addServiceDefinition(serviceID, content);
			}
		}

	}

	private String getSwaggerURL(ServiceInstance instance) {

		return instance.getUri().toString() + "swagger-ui.html";
	}

	public String getJSON(String serviceId, Object jsonData) throws JsonProcessingException {

		return new ObjectMapper().writeValueAsString(jsonData);
	}

}
