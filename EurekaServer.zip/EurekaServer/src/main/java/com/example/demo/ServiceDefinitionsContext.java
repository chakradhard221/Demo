package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentHashMap.KeySetView;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import springfox.documentation.swagger.web.SwaggerResource;

@Component
@Scope(scopeName = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class ServiceDefinitionsContext {
	private final ConcurrentHashMap<String, String> serviceDescriptions;

	private ServiceDefinitionsContext() {
		serviceDescriptions = new ConcurrentHashMap<>();
	}

	public String getSwaggerDefinition(String serviceId) {
		return this.serviceDescriptions.get(serviceId);
	}
	 public void addServiceDefinition(String serviceName, String serviceDescription){
		 serviceDescriptions.put(serviceName, serviceDescription);
	 }
	public List<SwaggerResource> getSwaggerDefinitions() {
		ArrayList<SwaggerResource> resourceList = new ArrayList<SwaggerResource>();
		KeySetView<String, String> keySet = serviceDescriptions.keySet();
		for (String key : keySet) {
			SwaggerResource resource = new SwaggerResource();

			resource.setLocation("/service/" + key);
			resource.setName(key);
			resource.setSwaggerVersion("2.0");
			resourceList.add(resource);
		}
		return resourceList;

	}

}
