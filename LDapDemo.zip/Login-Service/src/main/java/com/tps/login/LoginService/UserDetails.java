package com.tps.login.LoginService;

public class UserDetails {
	private String userName;
	private String password;
	private String rootUser;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRootUser() {
		return rootUser;
	}

	public void setRootUser(String rootUser) {
		this.rootUser = rootUser;
	}

	public UserDetails(String userName, String password, String rootUser) {
		super();
		this.userName = userName;
		this.password = password;
		this.rootUser = rootUser;
	}

	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UserDetails [userName=" + userName + ", password=" + password + ", rootUser=" + rootUser + "]";
	}
	
	}
