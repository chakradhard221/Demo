package com.tps.login.LoginService;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@CrossOrigin(origins = { "*" }, maxAge = 6000, allowCredentials = "false")

@RestController
@SpringBootApplication
public class LoginServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginServiceApplication.class, args);
	}

	
	@PostMapping("/login")
	public ResponseEntity<String> RestTemplate(@RequestBody UserDetails userDetails) throws JSONException {
		System.out.println("Enter the Home PageAdss...");
		System.out.println(userDetails);
		RestTemplate restTemplate = new RestTemplate();
		String plainCreds = "web-app:";
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
	
		System.out.println("BaseEncoded"+base64CredsBytes);
		String base64Creds = new String(base64CredsBytes);
		HttpHeaders headers = new HttpHeaders();
		
		headers.add("Authorization", "Basic " + base64Creds);
		MultiValueMap<String, String> request = new LinkedMultiValueMap<String, String>();
		request.add("grant_type", "password");
		System.out.println(userDetails.getRootUser());
		System.out.println(userDetails.getUserName());
		request.add("username", userDetails.getUserName() + "," + userDetails.getRootUser());
		request.add("password", userDetails.getPassword());
		request.add("client_id", "web-app");
		request.add("Authorization", "Basic " + base64Creds);
		System.err.println("MAPOBJECT"+request);
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(request,
				headers);
		System.err.println("Entity"+entity);
		ResponseEntity<String> loginResponse = restTemplate.exchange("http://localhost:5001/oauth/token",
				HttpMethod.POST, entity, String.class);
		System.err.println(loginResponse);
		System.err.println("........................");
		System.out.println("......token..."+loginResponse);
		
		return new ResponseEntity<String>(loginResponse.getBody(), HttpStatus.OK);
	}

}
