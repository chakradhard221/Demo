package com.tps.login.LoginService;

import org.json.JSONException;

public class Data {
	public static void main(String[] args) throws JSONException {
		

	}
}
