package com.example.demo;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;

@RestController
@RequestMapping("/api")
public class ServiceController2 {

@Autowired
private EurekaClient discoveryClient;
//private DiscoveryClient discoveryClient;
@GetMapping("/client2")
	public void doSomeWork() {
		RestTemplate restTemplate = new RestTemplate();
		
		Application application=discoveryClient.getApplication("client1");
		InstanceInfo info=application.getInstances().get(0);
	String hostName=info.getHostName();
	int port=info.getPort();
	
	String url="http://"+hostName+":"+port+"/api/getlist";
		ArrayList list = restTemplate.getForObject(url, ArrayList.class);
		System.err.println(list);
	}
}
