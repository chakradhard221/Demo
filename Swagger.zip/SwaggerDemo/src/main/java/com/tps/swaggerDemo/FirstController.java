package com.tps.swaggerDemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstController {
	@GetMapping("/first")
	public String demo() {
	return "..dataGet...122";
	}
	
}
