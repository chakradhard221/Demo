package com.example.demo;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.BasicAuth;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
@Configuration
public class SwaggerConfig{
	@Bean
	public Docket doIt() {
		ArrayList<SecurityScheme> arrayList = new ArrayList<>();
		arrayList.add(new BasicAuth("basicAuth"));
		return new Docket(DocumentationType.SWAGGER_2).groupName("Oauth").select()
				.apis(RequestHandlerSelectors.basePackage("com.example.demo")).build();
	}
}
