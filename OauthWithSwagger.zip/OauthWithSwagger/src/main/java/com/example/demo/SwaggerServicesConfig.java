package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

//@Primary
@Configuration
@EnableConfigurationProperties
//@EnableAutoConfiguration
//@ConfigurationProperties(prefix = "documentation.swagger.services")
@ConfigurationProperties(prefix ="document.swagger.services")
public class SwaggerServicesConfig {

	@Autowired
	List<SwaggerServices> listService;

	public List<SwaggerServices> getListService() {
		return listService;
	}

	public void setListService(List<SwaggerServices> listService) {
		this.listService = listService;
	}

}
