package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.google.common.base.Optional;

import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

@EnableAutoConfiguration
@Primary
@Configuration
@Order
public class GateWaySwaggerResourcesImple extends WebSecurityConfigurerAdapter implements SwaggerResourcesProvider {

	@Autowired
	private SwaggerServicesConfig swaggerServiceList;

	@Override
	public List<SwaggerResource> get() {
		// TODO Auto-generated method stub

		ArrayList<SwaggerResource> resources = new ArrayList<SwaggerResource>();
		List<SwaggerServices> listService = swaggerServiceList.getListService();
		for (SwaggerServices swaggerServices : listService) {
			resources.add(swaggerResource(swaggerServices.getName(), swaggerServices.getUrl(),swaggerServices.getVersion()));

		}
		return resources;
	}

	private SwaggerResource swaggerResource(String name, String location, String version) {
		SwaggerResource swaggerResource = new SwaggerResource();
		swaggerResource.setName(name);
		swaggerResource.setLocation(location);
		swaggerResource.setSwaggerVersion(version);
		return swaggerResource;
	}

//	private SwaggerResource swaggerResource(String groupString, String baseUrl) {
//		SwaggerResource swaggerResource = new SwaggerResource();
//		swaggerResource.setName(groupString);
//		swaggerResource.setLocation(swaggerLocation(baseUrl, groupString));
//		return swaggerResource;
//	}

	private String swaggerLocation(String swaggerUrl, String swaggerGroup) {
		String base = Optional.of(swaggerUrl).get();
		if (Docket.DEFAULT_GROUP_NAME.equals(swaggerGroup)) {
			return base;
		}
		return base + "?group=" + swaggerGroup;
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources/**",
				"/configuration/security", "/swagger-ui.html", "/webjars/**");
	}

}
