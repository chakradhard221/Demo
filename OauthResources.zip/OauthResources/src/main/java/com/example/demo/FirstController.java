package com.example.demo;

import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class FirstController {

	@GetMapping("/auth")
//	@PreAuthorize(value = "hasRole('CLIENT')" )
	public String doSomeWork() {
		System.out.println(".....authworked.......");
		return "workedOauth";
	}

}
