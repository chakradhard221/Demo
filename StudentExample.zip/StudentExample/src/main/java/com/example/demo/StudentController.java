package com.example.demo;

import java.awt.Color;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

import ar.com.fdvs.dj.core.DynamicJasperHelper;
import ar.com.fdvs.dj.core.layout.ClassicLayoutManager;
import ar.com.fdvs.dj.domain.DynamicReport;
import ar.com.fdvs.dj.domain.Style;
import ar.com.fdvs.dj.domain.builders.ColumnBuilder;
import ar.com.fdvs.dj.domain.builders.ColumnBuilderException;
import ar.com.fdvs.dj.domain.builders.DynamicReportBuilder;
import ar.com.fdvs.dj.domain.builders.StyleBuilder;
import ar.com.fdvs.dj.domain.constants.Border;
import ar.com.fdvs.dj.domain.constants.Font;
import ar.com.fdvs.dj.domain.constants.HorizontalAlign;
import ar.com.fdvs.dj.domain.constants.Transparency;
import ar.com.fdvs.dj.domain.constants.VerticalAlign;
import ar.com.fdvs.dj.domain.entities.columns.AbstractColumn;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@RestController
@CrossOrigin(origins = {"*"})
public class StudentController {
	
	@Autowired
	private StudentRepo studeRepo;

	@PostMapping("post")
	public String postData(@RequestBody Student string) {
		System.out.println("..string...."+string);
//		studeRepo.save(string);
		// System.out.println(".....postWorkedProperly.....");
		return "its Worked prop";
	}
	@GetMapping("get")
	public List<Student> getStudentData() {
		List<Student> findAll = studeRepo.findAll();
		return findAll;
	}
//	@GetMapping("get/{format}")
//	public String getData(@PathVariable("format") String reportFormate) throws FileNotFoundException, JRException {
//		File file = ResourceUtils.getFile("classpath:data.jrxml");
//		List<Student> students = studeRepo.findAll();
//		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
//JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(students);
////HashMap<String, Object> parameters = new HashMap<String,Object>();
////parameters.put("createdBy", "Solitx");
//JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport,null, dataSource);
//if(reportFormate.equalsIgnoreCase("html")) {
//	
//	JasperExportManager.exportReportToHtmlFile(jasperPrint,"/home/aswindia-23/Desktop/jsperReports/Student.html");
//}
//
//		 return "reportCompleted";
//	}

	@GetMapping("getjr")
	public String getData() throws JRException, ColumnBuilderException, ClassNotFoundException {

		JasperPrint jp = getReport();
		JasperExportManager.exportReportToHtmlFile(jp, "/home/aswindia-23/Desktop/jsperReports/noxml2.html");
//		JasperViewer jasperViewer = new JasperViewer(jp);
//		jasperViewer.setVisible(true);
		return "Worked....";
	}

	public JasperPrint getReport() throws ColumnBuilderException, JRException, ClassNotFoundException {
		Style headerStyle = createHeaderStyle();
		Style detailTextStyle = createDetailTextStyle();
		Style detailNumberStyle = createDetailNumberStyle();
		DynamicReport dynaReport = getReport(headerStyle, detailTextStyle, detailNumberStyle);

		List<Student> list = studeRepo.findAll();

		JasperPrint jp = DynamicJasperHelper.generateJasperPrint(dynaReport, new ClassicLayoutManager(),
				new JRBeanCollectionDataSource(list));
		return jp;
	}

	private Style createHeaderStyle() {
		StyleBuilder sb = new StyleBuilder(true);
		sb.setFont(Font.VERDANA_MEDIUM_BOLD);
		sb.setBorder(Border.THIN());
		sb.setBorderBottom(Border.PEN_2_POINT());
		sb.setBorderColor(Color.BLACK);
		sb.setBackgroundColor(Color.ORANGE);
		sb.setTextColor(Color.BLACK);
		sb.setHorizontalAlign(HorizontalAlign.CENTER);
		sb.setVerticalAlign(VerticalAlign.MIDDLE);
		sb.setTransparency(Transparency.OPAQUE);
		Style style = sb.build();

		return style;
	}

	private Style createDetailTextStyle() {
		StyleBuilder sb = new StyleBuilder(true);
		sb.setFont(Font.TIMES_NEW_ROMAN_BIG);
		sb.setBorder(Border.DOTTED());
		sb.setBorderColor(Color.BLACK);
		sb.setTextColor(Color.BLACK);
		sb.setHorizontalAlign(HorizontalAlign.LEFT);
		sb.setVerticalAlign(VerticalAlign.MIDDLE);
		sb.setPaddingLeft(5);
		return sb.build();
	}

	private Style createDetailNumberStyle() {
		StyleBuilder sb = new StyleBuilder(true);
		sb.setFont(Font.VERDANA_MEDIUM);
		sb.setBorder(Border.DOTTED());
		sb.setBorderColor(Color.BLACK);
		sb.setTextColor(Color.CYAN);
		sb.setHorizontalAlign(HorizontalAlign.RIGHT);
		sb.setVerticalAlign(VerticalAlign.MIDDLE);
		sb.setPaddingRight(5);
		return sb.build();
	}

	private AbstractColumn createColumn(String property, Class type, String title, int width, Style headerStyle,
			Style detailStyle) throws ColumnBuilderException {
		AbstractColumn columnState = ColumnBuilder.getNew().setColumnProperty(property, type.getName()).setTitle(title)
				.setWidth(Integer.valueOf(width)).setStyle(detailStyle).setHeaderStyle(headerStyle).build();
		return columnState;
	}

	private DynamicReport getReport(Style headerStyle, Style detailTextStyle, Style detailNumStyle)
			throws ColumnBuilderException, ClassNotFoundException {
		DynamicReportBuilder report = new DynamicReportBuilder();
		AbstractColumn columnEmpNo = createColumn("sno", Integer.class, "StudentNumber", 30, headerStyle,
				detailNumStyle);
		AbstractColumn columnName = createColumn("name", String.class, "Name", 30, headerStyle, detailTextStyle);
		AbstractColumn columnSalary = createColumn("mobile", String.class, "Mobile", 30, headerStyle, detailTextStyle);
		AbstractColumn columnCommission = createColumn("details", Object.class, "Details", 30, headerStyle,
				detailTextStyle);
		report.addColumn(columnEmpNo).addColumn(columnName).addColumn(columnSalary).addColumn(columnCommission);
		StyleBuilder titleStyle = new StyleBuilder(true);
		titleStyle.setHorizontalAlign(HorizontalAlign.CENTER);
		titleStyle.setFont(new Font(20, Font._FONT_VERDANA, true));

		StyleBuilder subTitleStyle = new StyleBuilder(true);
		subTitleStyle.setHorizontalAlign(HorizontalAlign.CENTER);
		subTitleStyle.setFont(new Font(Font.MEDIUM, Font._FONT_VERDANA, true));
		report.setTitle("Student Report");
		report.setTitleStyle(titleStyle.build());
		report.setSubtitle("Scholorship received by Student");
		report.setSubtitleStyle(subTitleStyle.build());
		report.setUseFullPageWidth(true);
		DynamicReport report2 = report.build();
		return report2;
	}
}
