

@org.hibernate.annotations.TypeDefs({
	@org.hibernate.annotations.TypeDef(name = "StudentUserType",typeClass = com.example.demo.StudentUserType.class)
})


package com.example.demo;





