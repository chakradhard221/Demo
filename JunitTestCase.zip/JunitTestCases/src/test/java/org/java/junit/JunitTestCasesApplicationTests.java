package org.java.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

//@RunWith(SpringRunner.class)
@SpringBootTest
public class JunitTestCasesApplicationTests {

	@Test
	public void contextLoads() throws Exception {
		System.err.println("......errrorr....");
		String obtainAccessToken = obtainAccessToken("ariadne", "asw", "ariadne");

		System.out.println(".....token......" + obtainAccessToken);

	}
	
	
	
	

	private String obtainAccessToken(String userName, String password, String rootUser) throws Exception {

		RestTemplate restTemplate = new RestTemplate();
		UserDetails userDetails = new UserDetails();
		userDetails.setPassword(password);
		userDetails.setRootUser(rootUser);
		userDetails.setUserName(userName);

		System.out.println("...userDetails..." + userDetails);

		String postForObject = restTemplate.postForObject("http://localhost:5055/login", userDetails, String.class);
		System.out.println("...postForObject..." + postForObject);

		JacksonJsonParser jsonParser = new JacksonJsonParser();
		return jsonParser.parseMap(postForObject).get("access_token").toString();

	}

}
