package org.java.junit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JuniTestController {
	@Autowired
	private EmployeeRepo repo;

	@PostMapping("/emp")
	public String home(@RequestBody Employee employee) {

		repo.save(employee);
		return "dataStored";
	}

}
