package com.example.demo;

import java.sql.Types;

import org.hibernate.dialect.PostgreSQL94Dialect;

public class CutomePostgreyDialect extends PostgreSQL94Dialect{
	
	public CutomePostgreyDialect(){
		this.registerColumnType(Types.JAVA_OBJECT, "json");
	}
}
