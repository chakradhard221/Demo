package com.example.demo;

import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "Loans_Info")
public class Loans {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer loanID;

	private String loanType;
	private String time;
	@Type(type = "LoansPersonDetailsType")
	private Map<String, Object> personDetails;

	public Integer getLoanID() {
		return loanID;
	}

	public void setLoanID(Integer loanID) {
		this.loanID = loanID;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Map<String, Object> getPersonDetails() {
		return personDetails;
	}

	public void setPersonDetails(Map<String, Object> personDetails) {
		this.personDetails = personDetails;
	}

	public Loans(Integer loanID, String loanType, String time, Map<String, Object> personDetails) {
		super();
		this.loanID = loanID;
		this.loanType = loanType;
		this.time = time;
		this.personDetails = personDetails;
	}

	@Override
	public String toString() {
		return "Loans [loanID=" + loanID + ", loanType=" + loanType + ", time=" + time + ", personDetails="
				+ personDetails + "]";
	}

}
