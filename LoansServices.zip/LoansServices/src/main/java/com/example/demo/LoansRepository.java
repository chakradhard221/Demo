/**
 * 
 */
package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

/**
 * @author aswindia-23
 *
 */
@Service
public interface LoansRepository extends JpaRepository<Loans, Integer> {

	
}
