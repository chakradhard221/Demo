package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoansController {

	@Autowired
	private LoansRepository loansRepository;
	
	@PostMapping("loan")
	public ResponseEntity<String> createLoan(@RequestBody Loans loans) {
		
		
		System.out.println("..loans..."+loans);
		Loans save = loansRepository.save(loans);
		return new ResponseEntity<String>("Loan CreatedS uccessFully",HttpStatus.OK);
	}
	@GetMapping("loan")
	public ResponseEntity<String> getLoan() {
		System.out.println(".....getLoans...");
		return new ResponseEntity<String>("Loan Retrived SuccessFully",HttpStatus.OK);
	}
}
