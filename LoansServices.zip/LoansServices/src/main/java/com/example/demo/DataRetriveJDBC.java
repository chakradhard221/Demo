package com.example.demo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DataRetriveJDBC {

	public static void main(String[] args) throws IOException {
byte[] bytes = "B".getBytes();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.write("B".getBytes());
		oos.flush();
		oos.close();
		baos.close();
		
		ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
		System.out.println(".....bnnnn..." + baos);

		ObjectInputStream objectInputStream = new ObjectInputStream(bais);
		int read = objectInputStream.read();
		
		System.out.println(".....readerrerererrere....."+read);
		byte[] b = baos.toByteArray();
		for (int x = 0; x < b.length; x++) {
			System.out.println("....bytArray..." + b[x]);
		}
//		ByteArrayInputStream bais = new ByteArrayInputStream(b);
		int available = bais.available();
		System.err.println("...vailablesss..."+available);
		for (int x = 0; x < b.length; x++) {
			System.out.println("....bytssssArray..." + bais.read());
		}
		int available2 = bais.available();
		System.err.println("...vailable...."+available2);
		System.out.println("...bais..."+bais.read());
		
		
	}
}
