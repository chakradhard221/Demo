
@TypeDefs(value = {
		@TypeDef(name = "LoansPersonDetailsType", typeClass =LoansPersonDetailsType.class) })
package com.example.demo;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
