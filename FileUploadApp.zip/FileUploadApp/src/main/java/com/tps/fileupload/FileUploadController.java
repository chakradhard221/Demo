package com.tps.fileupload;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import net.bytebuddy.implementation.bytecode.Throw;

@CrossOrigin(origins = { "*" }, maxAge = 6000, allowCredentials = "false")
@RestController
public class FileUploadController {
	// @PostMapping("/upload")
	// public ResponseEntity<Response> singleFileUpload(@RequestParam("file")
	// MultipartFile file) throws IOException {
	// System.out.println("...." + file);
	// System.err.println("...files..size...." + file);
	// // String UPLOAD_FOLDER = "/home/ubuntu/Documents/";
	// // String UPLOAD_FOLDER = "/home/aswindia-23/backUp/";
	// String UPLOAD_FOLDER = "/home/aswindia-23/Desktop/MavenJars/";
	// if (!file.isEmpty()) {
	// try {
	// // read and write the file to the selected location-
	// System.out.println("....in try....");
	// byte[] bytes = file.getBytes();
	// System.out.println("....file Into bytes....");
	// Path path = Paths.get(UPLOAD_FOLDER + file.getOriginalFilename());
	// System.out.println("....making Path....");
	// Files.write(path, bytes);
	// System.out.println("....Data Copied in Path....");
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	//
	// return new ResponseEntity<Response>(new Response(HttpStatus.OK.value(),
	// file.getOriginalFilename().toString() + " FileUploadedSuccessFully"),
	// HttpStatus.OK);
	//
	// } else {
	//
	// return new ResponseEntity<Response>(new
	// Response(HttpStatus.BAD_REQUEST.value(), "File Upload Failed"),
	// HttpStatus.BAD_REQUEST);
	// }
	//
	// }

	@PostMapping("upload/files")
	public ResponseEntity<Response> multiplefilesUpload(@RequestParam("files") ArrayList<MultipartFile> files) {

		String UPLOAD_FOLDER = "/home/aswindia-23/Desktop/MavenJars/";
		// String UPLOAD_FOLDER =
		// "/home/aswindia-23/Desktop/TPSsProjectWorkSpace-830/FileUploadApp/Images/";

		System.err.println("...files..size...." + files.size());
		if (!files.isEmpty()) {
			for (MultipartFile file : files) {

				try {
					// read and write the file to the selected location-
					System.out.println("....in try....");
					String fileName = file.getOriginalFilename();

					// String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
					// .path("/downloadFile/").path(fileName).toUriString();

					byte[] bytes = file.getBytes();
					System.out.println("....file Into bytes....");
					Path path = Paths.get(UPLOAD_FOLDER + file.getOriginalFilename());
					System.out.println("....making Path....");
					Files.write(path, bytes);
					System.out.println("....Data Copied in Path....");
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
			return new ResponseEntity<Response>(
					new Response(HttpStatus.OK.value(), "FilesUploadedSuccessFully at.." + UPLOAD_FOLDER),
					HttpStatus.OK);
		}

		return new ResponseEntity<Response>(
				new Response(HttpStatus.BAD_REQUEST.value(), "please choose a files(or)File Upload Failed"),
				HttpStatus.BAD_REQUEST);

	}

	@PostMapping("png/files")
	public FileUploadResponse doupload(@RequestParam("file") MultipartFile file) throws FileNotFoundException {

		String UPLOAD_FOLDER = "/home/aswindia-23/Desktop/MavenJars/";

		if (!file.isEmpty()) {

			try {
				// read and write the file to the selected location-
				System.out.println("....in try....");
				String fileName = file.getOriginalFilename();

				byte[] bytes = file.getBytes();
				System.out.println("....file Into bytes....");
				Path path = Paths.get(UPLOAD_FOLDER + file.getOriginalFilename());
				System.out.println("....making Path....");
				Files.write(path, bytes);
				
				
				String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
						.path(fileName).toUriString();
				
				System.out.println("...fileDownloadUri......" + fileDownloadUri);
				System.out.println("....Data Copied in Path....");
				return new FileUploadResponse(fileName, fileDownloadUri, file.getContentType(), file.getSize());
			} catch (IOException e) {

				throw new FileStorageException("file could't Uploaded");
			}

			
		}
	
		throw new FileNotFoundException("file NotFound");

	}

	@PostMapping("profile")
	public void profileData(@ModelAttribute ProfileRequest req) {
		System.out.println("...file.." + req);
	}

}