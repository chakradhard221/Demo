package com.tps.fileupload;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
public class MyFileNotFoundException extends RuntimeException {
	public MyFileNotFoundException(String message) {
        super(message);
    }

    public MyFileNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
