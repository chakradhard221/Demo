package com.tps.fileupload;

import org.springframework.web.multipart.MultipartFile;

public class ProfileRequest {
	private String profile;
	private String imageData;
	private String extension;
	private String name;
	private String type;
	private MultipartFile file;
	
	
	
	
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getImageData() {
		return imageData;
	}
	public void setImageData(String imageData) {
		this.imageData = imageData;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "ProfileRequest [profile=" + profile + ", imageData=" + imageData + ", extension=" + extension
				+ ", name=" + name + ", type=" + type + ", file=" + file + "]";
	}
	public ProfileRequest(String profile, String imageData, String extension, String name, String type,
			MultipartFile file) {
		super();
		this.profile = profile;
		this.imageData = imageData;
		this.extension = extension;
		this.name = name;
		this.type = type;
		this.file = file;
	}
	
	
	
	
	
	

}
