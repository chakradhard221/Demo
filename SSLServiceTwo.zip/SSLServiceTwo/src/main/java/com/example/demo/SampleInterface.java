package com.example.demo;

public interface SampleInterface {

	public static void getStatic() {

	}

	public default void getDefault() {

	}

	public void getInstance();


}
