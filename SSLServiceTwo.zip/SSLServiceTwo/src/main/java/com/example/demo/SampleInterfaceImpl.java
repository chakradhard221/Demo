package com.example.demo;

public class SampleInterfaceImpl implements SampleInterface {

	@Override
	public void getInstance() {
	
		
	}

	public void gteIT() {
		SampleInterface.getStatic();
		SampleInterfaceImpl impl = new SampleInterfaceImpl();
		
	}
	
	
	
}
