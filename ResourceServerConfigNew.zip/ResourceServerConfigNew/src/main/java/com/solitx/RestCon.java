package com.solitx;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class RestCon {
	@GetMapping("get")
	@PreAuthorize("hasAuthority('ALL')")
	public String getData() {
		System.out.println("..fromRest..");
		return ".dataGot..";
	}
}
