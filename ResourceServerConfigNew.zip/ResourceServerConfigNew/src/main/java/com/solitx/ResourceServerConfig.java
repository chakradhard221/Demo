package com.solitx;

import java.util.Collection;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;

@Configuration
public class ResourceServerConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("....httpCall...");
		http.oauth2ResourceServer().jwt().jwtAuthenticationConverter(authoryExtractor());
		http.authorizeRequests().anyRequest().authenticated();
	}

	public JwtAuthenticationConverter authoryExtractor() {
		JwtAuthenticationConverter authenticationConverter = new JwtAuthenticationConverter();
		authenticationConverter.setJwtGrantedAuthoritiesConverter(new GrantedAuthorityExtractorSupport());
		return authenticationConverter;
	}

	public class GrantedAuthorityExtractorSupport implements Converter<Jwt, Collection<GrantedAuthority>> {

		@Override
		public Collection<GrantedAuthority> convert(Jwt source) {
			// TODO Auto-generated method stub
			Collection<String> authorities = (Collection<String>) source.getClaims().get("authorities");

			return authorities.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
		}

	}
}
