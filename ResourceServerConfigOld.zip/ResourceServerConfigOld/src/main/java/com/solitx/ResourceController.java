package com.solitx;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = { "*" })
public class ResourceController {
	@GetMapping("dataGet")
	public String getData() {
		System.out.println("....dataPrc...");
		return "DataGet";
	}
}
