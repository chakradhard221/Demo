package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@EnableWebSecurity
@Configuration
@EnableResourceServer
public class WebServerConf extends WebSecurityConfigurerAdapter {

	@Autowired
	private PasswordEncoder encoder;

	@Override
	@Bean
	public UserDetailsService userDetailsService() {
		UserDetails user = User.builder().username("chandu").password(encoder.encode("asdf")).roles("USER").build();
		UserDetails userAdmin = User.builder().username("admin").password(encoder.encode("secret")).roles("ADMIN")
				.build();

		return new InMemoryUserDetailsManager(user, userAdmin);
	}

	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		// TODO Auto-generated method stub
		return super.authenticationManagerBean();
	}
}
