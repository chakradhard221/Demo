
//   console.log("am from JAvascriptFile");
// let a=10;
//   console.log(a)
//   let person={
//       id:10,
//       name:'chakradhar'
//   }
// console.log(person['id'])

// var car1='maruti'
// var car2='zen'
// var car3='xylo'
// var namesList=[
//    car1,car2,car3
// ]

// console.log(namesList)
// namesList.forEach(carname=>{
// // alert(carname)
// console.log(carname)
// })

function myFormData(form){
    form.preventDefault();
    // var x = document.forms["myForm"]["name"].value;
    console.log("..myFormDataCalled....."+form)
}


document.getElementById("para").innerHTML="goodeveng"
