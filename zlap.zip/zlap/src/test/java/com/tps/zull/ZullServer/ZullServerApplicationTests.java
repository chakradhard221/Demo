package com.tps.zull.ZullServer;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class ZullServerApplicationTests {
//
//	@Test
//	public void contextLoads() {
//	}

}
