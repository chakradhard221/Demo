package com.tps.zull.ZullServer.Entity;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

@Entity
public class RootUserFormTemplates {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rootUserFormTemplateID;
	@Type(type = "UserDetailsTemplateDataUserType")
	@Column(name = "rootUserFormTemplate")
	private Map<String, Object> rootUserFormTemplate = new LinkedHashMap<>(0);

	public int getRootUserFormTemplateID() {
		return rootUserFormTemplateID;
	}

	public void setRootUserFormTemplateID(int rootUserFormTemplateID) {
		this.rootUserFormTemplateID = rootUserFormTemplateID;
	}

	public Map<String, Object> getRootUserFormTemplate() {
		return rootUserFormTemplate;
	}

	public void setRootUserFormTemplate(Map<String, Object> rootUserFormTemplate) {
		this.rootUserFormTemplate = rootUserFormTemplate;
	}

	@Override
	public String toString() {
		return "RootUserFormTemplates [rootUserFormTemplateID=" + rootUserFormTemplateID + ", rootUserFormTemplate="
				+ rootUserFormTemplate + "]";
	}

	public RootUserFormTemplates(Map<String, Object> rootUserFormTemplate) {
		super();
		this.rootUserFormTemplate = rootUserFormTemplate;
	}

	public RootUserFormTemplates() {
		super();
		// TODO Auto-generated constructor stub
	}

}
