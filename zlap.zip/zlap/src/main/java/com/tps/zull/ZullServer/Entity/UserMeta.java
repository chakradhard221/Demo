package com.tps.zull.ZullServer.Entity;

import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "UserMeta")

public class UserMeta {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "userid")
	private UUID userID;
	
	@OneToMany(mappedBy = "userMeta", cascade = { CascadeType.ALL })
	private List<UserRoles> userRolesAttached;
	
	@OneToMany(mappedBy = "userMeta", cascade = { CascadeType.ALL })
	private List<UserGroupMembers> userGroupMembers;

	@OneToOne(mappedBy = "userMeta", cascade = { CascadeType.ALL })
	UserConfigs userConfigs;

	private String rootUserID;
	private String recordCreatorID;
	private String userName;
	private String password;
	
	@OneToOne
	@JoinColumn(name = "userProfileID")
	UserProfiles userProfiles;

	public UserConfigs getUserConfigs() {
		return userConfigs;
	}

	public void setUserConfigs(UserConfigs userConfigs) {
		this.userConfigs = userConfigs;
	}

	public String getRootUserID() {
		return rootUserID;
	}

	public void setRootUserID(String rootUserID) {
		this.rootUserID = rootUserID;
	}

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public UserProfiles getUserProfiles() {
		return userProfiles;
	}

	public void setUserProfiles(UserProfiles userProfiles) {
		this.userProfiles = userProfiles;
	}

	public UUID getUserID() {
		return userID;
	}

	public void setUserID(UUID userID) {
		this.userID = userID;
	}

	public UserMeta() {
		super();
	}

	public UserMeta(UUID userID) {
		super();
		this.userID = userID;
	}

	public UserMeta(UUID userID, String userName) {
		super();
		this.userID = userID;
	}

	public List<UserRoles> getUserRolesAttached() {
		return userRolesAttached;
	}

	public void setUserRolesAttached(List<UserRoles> userRolesAttached) {
		this.userRolesAttached = userRolesAttached;
	}

	public List<UserGroupMembers> getUserGroupMembers() {
		return userGroupMembers;
	}

	public void setUserGroupMembers(List<UserGroupMembers> userGroupMembers) {
		this.userGroupMembers = userGroupMembers;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserMeta(String rootUserID, String ownerID, String userName, String password) {
		super();
		this.rootUserID = rootUserID;
		this.recordCreatorID = ownerID;
		this.userName = userName;
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserMeta [userID=" + userID + ", userRolesAttached=" + userRolesAttached + ", userGroupMembers="
				+ userGroupMembers + ", userConfigs=" + userConfigs + ", rootUserID=" + rootUserID
				+ ", recordCreatorID=" + recordCreatorID + ", userName=" + userName + ", password=" + password
				+ ", userProfiles=" + userProfiles + "]";
	}

}
