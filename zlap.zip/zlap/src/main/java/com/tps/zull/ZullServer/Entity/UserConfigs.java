package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;

@Entity
public class UserConfigs implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	@OneToOne
	@JoinColumn(name = "userID")
	private UserMeta userMeta;
	@Type(type = "UserDetailsTemplateDataUserType")
	private Map<String, Object> userConfigs = new LinkedHashMap<>(0);

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public UserMeta getUserMeta() {
		return userMeta;
	}

	public void setUserMeta(UserMeta userMeta) {
		this.userMeta = userMeta;
	}

	public Map<String, Object> getUserConfigs() {
		return userConfigs;
	}

	public void setUserConfigs(Map<String, Object> userConfigs) {
		this.userConfigs = userConfigs;
	}

	public UserConfigs(UserMeta userMeta, Map<String, Object> userConfigs) {
		super();
		this.userMeta = userMeta;
		this.userConfigs = userConfigs;
	}

	@Override
	public String toString() {
		return "UserConfigs [Id=" + Id + ",userConfigs=" + userConfigs + "]";
	}

	public UserConfigs() {
		super();
		// TODO Auto-generated constructor stub
	}

}
