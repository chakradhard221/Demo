//@TypeDef(name = "ProductTemplateDataUserType", typeClass = ProductTemplateDataUserType.class)

@TypeDefs({ @TypeDef(name = "UserDetailsTemplateDataUserType", typeClass = UserDetailsTemplateDataUserType.class) })
package com.tps.zull.ZullServer.services;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

