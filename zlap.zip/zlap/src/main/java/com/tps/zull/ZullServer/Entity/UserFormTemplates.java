package com.tps.zull.ZullServer.Entity;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;

@Entity
public class UserFormTemplates {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userFormTemplateID;
	@Type(type = "UserDetailsTemplateDataUserType")
	@Column(name = "userFormTemplate")
	private Map<String, Object> userFormTemplate = new LinkedHashMap<>(0);
	private String rootUserID;
	private String recordCreatorID;

	public int getUserFormTemplateID() {
		return userFormTemplateID;
	}

	public void setUserFormTemplateID(int userFormTemplateID) {
		this.userFormTemplateID = userFormTemplateID;
	}

	public Map<String, Object> getUserFormTemplate() {
		return userFormTemplate;
	}

	public void setUserFormTemplate(Map<String, Object> userFormTemplate) {
		this.userFormTemplate = userFormTemplate;
	}

	public String getRootUserID() {
		return rootUserID;
	}

	public void setRootUserID(String rootUserID) {
		this.rootUserID = rootUserID;
	}

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public UserFormTemplates(Map<String, Object> userFormTemplate, String rootUserID, String ownerID) {
		super();
		this.userFormTemplate = userFormTemplate;
		this.rootUserID = rootUserID;
		this.recordCreatorID = ownerID;
	}

	@Override
	public String toString() {
		return "UserFormTemplates [userFormTemplateID=" + userFormTemplateID + ", userFormTemplate=" + userFormTemplate
				+ ", rootUserID=" + rootUserID + ", ownerID=" + recordCreatorID + "]";
	}

	public UserFormTemplates() {
		super();
		// TODO Auto-generated constructor stub
	}

}
