package com.tps.zull.ZullServer.Entity;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class UserProfiles {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
	private UUID userProfileID;
	@Type(type = "UserDetailsTemplateDataUserType")
	@Column(name = "userProfile")
	private Map<String, Object> userProfile = new LinkedHashMap<>(0);
	@OneToOne(mappedBy = "userProfiles", cascade = { CascadeType.ALL })
	private UserMeta userMeta;

	public UUID getUserProfileID() {
		return userProfileID;
	}

	public void setUserProfileID(UUID userProfileID) {
		this.userProfileID = userProfileID;
	}

	public Map<String, Object> getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(Map<String, Object> userProfile) {
		this.userProfile = userProfile;
	}

	public UserMeta getUserMeta() {
		return userMeta;
	}

	public void setUserMeta(UserMeta userMeta) {
		this.userMeta = userMeta;
	}

	@Override
	public String toString() {
		return "UserProfiles [userProfileID=" + userProfileID + ", userProfile=" + userProfile + "]";
	}

	public UserProfiles(Map<String, Object> userProfile) {
		super();

		this.userProfile = userProfile;

	}

	public UserProfiles() {
		super();
	}

}
