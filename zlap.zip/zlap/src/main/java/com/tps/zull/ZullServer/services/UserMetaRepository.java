package com.tps.zull.ZullServer.services;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tps.zull.ZullServer.Entity.UserMeta;

@Service
@Transactional
public interface UserMetaRepository extends JpaRepository<UserMeta, UUID> {

	public List<UserMeta> findByUserName(String username);
	@Query("from UserMeta where rootUserID=:rootUserID and userName=:userName")
	public UserMeta findbyUserMetaByRootUserIDAndUserName(@Param("rootUserID") String rootUserId,
			@Param("userName") String userName);
}
