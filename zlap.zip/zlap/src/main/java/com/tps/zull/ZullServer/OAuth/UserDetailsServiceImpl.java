package com.tps.zull.ZullServer.OAuth;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.tps.zull.ZullServer.Entity.ActionResponse;
import com.tps.zull.ZullServer.Entity.RootUserMeta;
import com.tps.zull.ZullServer.Entity.UserGroupMeta;
import com.tps.zull.ZullServer.Entity.UserMeta;
import com.tps.zull.ZullServer.Entity.UserRoleMeta;
import com.tps.zull.ZullServer.services.RootUserMetaRepository;
import com.tps.zull.ZullServer.services.RootUserProfilesRepository;
import com.tps.zull.ZullServer.services.UserGroupMetaRepository;
import com.tps.zull.ZullServer.services.UserMetaRepository;
import com.tps.zull.ZullServer.services.UserProfilesRepository;
import com.tps.zull.ZullServer.services.UserRoleMetaRepository;
import com.tps.zull.ZullServer.services.ZullServiceUtils;

@Service
@Transactional
public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	UserMetaRepository userMetaRepository;
	@Autowired
	RootUserMetaRepository rootUserMetaRepository;
	@Autowired
	UserRoleMetaRepository userRoleMetaRepository;
	@Autowired
	UserGroupMetaRepository userGroupMetaRepository;
	@Autowired
	RootUserProfilesRepository rootUserProfilesRepository;
	@Autowired
	UserProfilesRepository userProfilesRepository;

	@Override
	public UserDetails loadUserByUsername(String loginDetails) throws UsernameNotFoundException {

		System.out.println("loginDetails :" + loginDetails);
		String userID = "";
		String rootuserID = "";
		String username = loginDetails.split(",")[0];
		String rootUserName = loginDetails.split(",")[1];
		String rootUserProfileID = "";
		String password = "";
		String flag = "";
		boolean isAccountNonExpired;
		boolean isAccountNonLocked;
		boolean isCredentialsNonExpired;
		boolean isEnabled;

		
		List<RootUserMeta> rootUserMeta = rootUserMetaRepository.findByUserName(rootUserName);
		UserMeta userMeta = userMetaRepository
				.findbyUserMetaByRootUserIDAndUserName(rootUserMeta.get(0).getRootUserID().toString(), username);

		Map<String, Object> map1 = new HashMap<>();

		map1.put(rootUserMeta.get(0).getRootUserID().toString(),
				rootUserMeta.get(0).getRootUserProfiles().getRootUserProfileID());

		Collection<Authority> authorities = new ArrayList<>();

		Map<Integer, ActionResponse> map = ZullServiceUtils.actionResponseMap();

		if (rootUserName.equalsIgnoreCase(username) && rootUserMeta != null) {
			
			List<RootUserMeta> rootUserMetas = rootUserMetaRepository.findByUserName(rootUserName);
			userID = rootUserMetas.get(0).getRootUserID().toString();
			authorities.add(new Authority("ALL"));
			rootuserID = rootUserMetas.get(0).getRootUserID().toString();
			password = rootUserMetas.get(0).getPassword();
			rootUserProfileID = rootUserMetas.get(0).getRootUserProfiles().getRootUserProfileID().toString();
			flag = "ROOTUSER";
			isAccountNonExpired = true;
			isAccountNonLocked = true;
			isCredentialsNonExpired = true;
			isEnabled = true;

		} else if (userMeta != null) {

			flag = "USER";
			userID = userMeta.getUserID().toString();
			password = userMeta.getPassword();
			rootuserID = userMeta.getRootUserID();
			isAccountNonExpired = true;
			isAccountNonLocked = true;
			isCredentialsNonExpired = true;
			isEnabled = true;

			if (map1.containsKey(rootuserID)) {
				rootUserProfileID = map1.get(rootuserID).toString();
			}

			try {
				if (userMeta.getUserGroupMembers() != null) {
					if (!userMeta.getUserGroupMembers().isEmpty()) {
						userMeta.getUserGroupMembers().forEach((userGroupMember) -> {
							UserGroupMeta userGroupMeta = userGroupMetaRepository.findOne(userGroupMember.getGroupID());
							userGroupMeta.getUserRolGroupRoles().forEach((userGroupRole) -> {
								UserRoleMeta userRoleMeta = userRoleMetaRepository.findOne(userGroupRole.getRoleID());
								userRoleMeta.getUserRoleAttachedActions().forEach((actions) -> {
									authorities
											.add(new Authority(map.get(actions.getPermissionID()).getPermissionName()));
								});

							});

						});
					}
				}
				if (userMeta.getUserRolesAttached() != null) {
					if (!userMeta.getUserRolesAttached().isEmpty()) {
						userMeta.getUserRolesAttached().forEach((userRole) -> {
							UserRoleMeta userRoleMeta = userRoleMetaRepository.findOne(userRole.getRoleID());
							userRoleMeta.getUserRoleAttachedActions().forEach((actions) -> {
								authorities.add(new Authority(map.get(actions.getPermissionID()).getPermissionName()));
							});

						});
					}
				}

			} catch (Exception e) {
				e.printStackTrace();

			}

		}

		else {
			System.out.println("Invalid User...");
			userID = "";
			authorities.add(null);
			rootuserID = "";
			password = "";
			rootUserProfileID = "";
			flag = "UNKNOWNUSER";
			isAccountNonExpired = false;
			isAccountNonLocked = false;
			isCredentialsNonExpired = false;
			isEnabled = false;
		}

		return new UserDetailsOAuth(userID + "," + flag + "," + rootuserID + "," + rootUserProfileID, password,
				isAccountNonExpired, isCredentialsNonExpired, isAccountNonLocked, isEnabled, authorities);

//		System.out.println("rootUserMeta :" + rootUserMeta);
//		Map<String, Object> map1 = new HashMap<>();
//
//		map1.put(rootUserMeta.get(0).getRootUserID().toString(),
//				rootUserMeta.get(0).getRootUserProfiles().getRootUserProfileID());
//
//		UserMeta userMeta = userMetaRepository
//				.findbyUserMetaByRootUserIDAndUserName(rootUserMeta.get(0).getRootUserID().toString(), username);
//
//		System.out.println("userMeta :" + userMeta);
//
//		Collection<Authority> authorities = new ArrayList<>();
//
//		Map<Integer, ActionResponse> map = ZullServiceUtils.actionResponseMap();
//
//		if (userMeta == null) {
//
////			return new UserDetailsOAuth(null,null,false,false,false,false,null);
//
//			List<RootUserMeta> rootUserMetas = rootUserMetaRepository.findByUserName(rootUserName);
//			userID = rootUserMetas.get(0).getRootUserID().toString();
//			authorities.add(new Authority("ALL"));
//			rootuserID = rootUserMetas.get(0).getRootUserID().toString();
//			password = rootUserMetas.get(0).getPassword();
//			rootUserProfileID = rootUserMetas.get(0).getRootUserProfiles().getRootUserProfileID().toString();
//			flag = "ROOTUSER";
//
//		} else {
//
//			flag = "USER";
//			userID = userMeta.getUserID().toString();
//			password = userMeta.getPassword();
//			rootuserID = userMeta.getRootUserID();
//
//			if (map1.containsKey(rootuserID)) {
//				rootUserProfileID = map1.get(rootuserID).toString();
//			}
//
//			try {
//				if (userMeta.getUserGroupMembers() != null) {
//					if (!userMeta.getUserGroupMembers().isEmpty()) {
////						System.out.println(userMeta.getUserGroupMembers());
//						userMeta.getUserGroupMembers().forEach((userGroupMember) -> {
//							UserGroupMeta userGroupMeta = userGroupMetaRepository.findOne(userGroupMember.getGroupID());
////							System.out.println(userGroupMeta);
////							System.out.println(userGroupMeta.getUserRolGroupRoles());
//							userGroupMeta.getUserRolGroupRoles().forEach((userGroupRole) -> {
//								UserRoleMeta userRoleMeta = userRoleMetaRepository.findOne(userGroupRole.getRoleID());
////								System.out.println(userRoleMeta);
////								System.out.println(userRoleMeta.getUserRoleAttachedActions());
//								userRoleMeta.getUserRoleAttachedActions().forEach((actions) -> {
//									authorities
//											.add(new Authority(map.get(actions.getPermissionID()).getPermissionName()));
//								});
//
//							});
//
//						});
//					}
//				}
////				System.out.println("...............");
//				if (userMeta.getUserRolesAttached() != null) {
//					if (!userMeta.getUserRolesAttached().isEmpty()) {
////						System.out.println(userMeta.getUserRolesAttached());
//						userMeta.getUserRolesAttached().forEach((userRole) -> {
//							UserRoleMeta userRoleMeta = userRoleMetaRepository.findOne(userRole.getRoleID());
////							System.out.println(userRoleMeta);
////							System.out.println(userRoleMeta.getUserRoleAttachedActions());
//							userRoleMeta.getUserRoleAttachedActions().forEach((actions) -> {
//								authorities.add(new Authority(map.get(actions.getPermissionID()).getPermissionName()));
//							});
//
//						});
//					}
//				}
//
//			} catch (Exception e) {
//				e.printStackTrace();
//
//			}
//
//		}
//
//		if (!userID.equalsIgnoreCase("")) {
//			UserDetailsOAuth auth = new UserDetailsOAuth(
//					userID + "," + flag + "," + rootuserID + "," + rootUserProfileID, password, true, true, true, true,
//					authorities);
//			System.out.println("AUTH :" + auth);
//			return auth;
//		}
//		throw new UsernameNotFoundException(username);
	}

}
