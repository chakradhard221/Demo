package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//@Data
@Entity
@Table(name = "user_role_meta")
public class UserRoleMeta implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "roleid")
	private int roleID;
	private String roleName;

//	private String ownerUserID;
	private String recordCreatorID;
	private String rootUserID;
	@OneToMany(mappedBy = "userRoleMeta", cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	private Set<UserRole> userRoleAttachedActions = new HashSet<UserRole>(0);

	public UserRoleMeta() {
		super();
		// TODO Auto-generated constructor stub
	}

//	public UserRoleMeta(String rollName, String ownerUserID) {
//		super();
//		this.roleName = rollName;
//		this.ownerUserID = ownerUserID;
//
	// }

	public int getRoleID() {
		return roleID;
	}

	public UserRoleMeta(String roleName, String ownerUserID, String rootUserID) {
	super();
	this.roleName = roleName;
	this.recordCreatorID = ownerUserID;
	this.rootUserID = rootUserID;
}

	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public Set<UserRole> getUserRoleAttachedActions() {
		return userRoleAttachedActions;
	}

	public void setUserRoleAttachedActions(Set<UserRole> userRoleAttachedActions) {
		this.userRoleAttachedActions = userRoleAttachedActions;
	}

	public String getRootUserID() {
		return rootUserID;
	}

	public void setRootUserID(String rootUserID) {
		this.rootUserID = rootUserID;
	}

	@Override
	public String toString() {
		return "UserRoleMeta [roleID=" + roleID + ", roleName=" + roleName + ", ownerUserID=" + recordCreatorID + "]";
	}

}
