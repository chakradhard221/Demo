package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_group_roles")
public class UserGroupRoles implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	private int roleID;
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "group_id", nullable = false)
	private UserGroupMeta userGroupMeta;
	private String recordCreatorID;

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public UserGroupRoles() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserGroupRoles(int roleID, UserGroupMeta userGroupMeta, String recordCreatorID) {
		super();
		this.roleID = roleID;
		this.userGroupMeta = userGroupMeta;
		this.recordCreatorID = recordCreatorID;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getRoleID() {
		return roleID;
	}

	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}

	public UserGroupMeta getUserGroupMeta() {
		return userGroupMeta;
	}

	public void setUserGroupMeta(UserGroupMeta userGroupMeta) {
		this.userGroupMeta = userGroupMeta;
	}

	@Override
	public String toString() {
		return "UserGroupRoles [Id=" + Id + ", roleID=" + roleID + ", recordCreatorID=" + recordCreatorID + "]";
	}

//	@Override
//	public String toString() {
//		return "UserGroupRoles [Id=" + Id + ", roleID=" + roleID + ", recordCreatorID=" + recordCreatorID + "]";
//	}

	
	
}
