package com.tps.zull.ZullServer.services;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.tps.zull.ZullServer.Entity.ActionResponse;

public class ZullServiceUtils {
	public static List<ActionResponse> actionslist() {
		return Arrays.asList(

//				-------------------from users------------------------
				new ActionResponse(1, "PROVIDE_VISIBLE_ROOTUSERS"), new ActionResponse(2, "PROVIDE_ROOTUSER_DETAILS"),
				new ActionResponse(3, "EDIT_ROOTUSER_DETAILS"), new ActionResponse(4, "EDIT_ROOTUSER_CONFIGS"),
				new ActionResponse(5, "EDIT_ROOTUSER_DETAILS_VISIBILITY"),
				new ActionResponse(6, "PROVIDE_ROOTUSER_VISIBILITY"), new ActionResponse(7, "DELETE_ROOTUSER_PROFILES"),
				new ActionResponse(8, "CREATE_USERFORM"), new ActionResponse(9, "EDIT_USERFORM"),
				new ActionResponse(10, "PROVIDE_USERFORMS_LABELS"), new ActionResponse(11, "PROVIDE_USERFORM"),
				new ActionResponse(12, "PROVIDE_ROOTUSER_CONFIGS"), new ActionResponse(13, "CREATE_USER"),
				new ActionResponse(14, "EDIT_USER_DETAILS"), new ActionResponse(15, "EDIT_USERCONFIGS"),
				new ActionResponse(16, "ATTACH_USERROLES_TO_USER"), new ActionResponse(17, "ATTACH_USER_TO_USERGROUPS"),
				new ActionResponse(18, "DETACH_USERROLES_FROM_USERS"),
				new ActionResponse(19, "DETACH_USERGROUPS_FROM_USERS"), new ActionResponse(20, "PROVIDE_USERS"),
				new ActionResponse(21, "PROVIDE_USERDETAILS"), new ActionResponse(22, "PROVIDE_USERCONFIGS"),
				new ActionResponse(23, "PROVIDE_USERROLES_BY_USER"),
				new ActionResponse(24, "PROVIDE_USERGROUPS_BY_USER"), new ActionResponse(25, "DELETE_USER"),
				new ActionResponse(26, "CREATE_USERGROUP"), new ActionResponse(27, "EDIT_USERGROUP"),
				new ActionResponse(28, "ATTACH_USERROLES_TO_USERGROUP"), new ActionResponse(29, "PROVIDE_USERGROUPS"),
				new ActionResponse(30, "PROVIDE_USERGROUP_DETAILS"), new ActionResponse(31, "PROVIDE_USERROLES"),
				new ActionResponse(32, "DELETE_USERGROUP"), new ActionResponse(33, "DETACH_USERROLES_FROM_USERGROUP"),
				new ActionResponse(34, "DETACH_USERS_FROM_USERGROUP"), new ActionResponse(35, "CREATE_USERROLE"),
				new ActionResponse(36, "EDIT_USERROLE"), new ActionResponse(37, "ATTACH_USERACTIONS_TO_USERROLE"),
				new ActionResponse(38, "PROVIDE_USERROLE_DETAILS"), new ActionResponse(39, "PROVIDE_USERACTIONS"),
				new ActionResponse(40, "DELETE_USERROLES"), new ActionResponse(41, "DETACH_USERACTIONS_FROM_USERROLE"),

				// --------------------from profiles------------------
				new ActionResponse(42, "CREATE_PROFILE"), new ActionResponse(43, "LINK_PROFILE"),
				new ActionResponse(44, "UPDATE_PROFILE"), new ActionResponse(45, "UPDATE_PROFILE_STATUS"),
				new ActionResponse(46, "DELETE_PROFILE"), new ActionResponse(47, "DELETE_PROFILE_LINK"),
				new ActionResponse(48, "PROVIDE_PROFILE"), new ActionResponse(49, "PROVIDE_BY_VISISBILITY"),
				new ActionResponse(50, "PROVIDE_PROFILE_LINK"), new ActionResponse(51, "CREATE_PROFILE_FORM"),
				new ActionResponse(52, "UPDATE_PROFILE_FORM"), new ActionResponse(53, "PROVIDE_PROFILE_FORM"),
				new ActionResponse(54, "DELETE_PROFILE_FORM"),

//			-----------------------from products---------------------
				new ActionResponse(55, "CREATE_PRODUCT"), new ActionResponse(56, "UPDATE_PRODUCT"),
				new ActionResponse(57, "UPDATE_PRODUCT_STATUS"), new ActionResponse(58, "PROVIDE_PRODUCTS"),
				new ActionResponse(59, "DELETE_PRODUCTS"), new ActionResponse(60, "PROVIDE_PRODUCTS1"),

				// ---------------from payments------------
				new ActionResponse(61, "CREATE_METHOD"), new ActionResponse(62, "CREATE_SERVICE_METHOD"),
				new ActionResponse(63, "CREATE_BILLING_METHOD"), new ActionResponse(64, "CREATE_PROFILESERVICE_METHOD"),
				new ActionResponse(65, "CREATE_PROFILEBILLING_METHOD"), new ActionResponse(66, "UPDATE_METHOD"),
				new ActionResponse(67, "UPDATE_BALANCE"), new ActionResponse(68, "PROVIDE_METHOD"),
				new ActionResponse(69, "DELETE_METHOD"), new ActionResponse(70, "DISCOVER_TRANSACTIONS"),

				// ---------------------------from deals-------------------
				new ActionResponse(71, "CREATE_DEAL"), new ActionResponse(72, "UPDATE_DEAL"),
				new ActionResponse(73, "UPDATE_DEAL_STATUS"), new ActionResponse(74, "SIGN_DEAL"),
				new ActionResponse(75, "PROVIDE_DEALS"), new ActionResponse(76, "PROVIDE_DEAL_STATUS"),
				new ActionResponse(77, "DELETE_DEAL"),

//				--------------------from contracts-------------------------
				new ActionResponse(78, "CREATE_PAYMENTMETHOD_CONTRACT"), new ActionResponse(79, "PROVIDE_CONTRACTS"),
				new ActionResponse(80, "PROVIDE_CONTRACTS_STATUS"), new ActionResponse(81, "PROVIDE_CONTRACTID"),
				new ActionResponse(82, "COMPUTE_SCHEDULE"),

//				------------------"from events--------------------
				new ActionResponse(83, "REGISTER_OPS_EVENTS"), new ActionResponse(84, "PROVIDE_EVENTS"),

//				----------------------from transactions---------------------
				new ActionResponse(85, "UPDATE_TRANSACTION_STATUS"), new ActionResponse(86, "PROVIDE_TRANSACTIONS"),
				new ActionResponse(87, "UPDATE_TRANSACTION_DUEDATE"), new ActionResponse(88, "MATCH_TRANSACTION"),
				new ActionResponse(89, "PROCESS_TRANSACTION_MANUAL"), new ActionResponse(90, "TRANSACTION_CONFIRM"),

//				-------------------from ledgers-----------------------
				new ActionResponse(91, "CREATE_CUSTOM_LEDGER_ACCOUNTS"), new ActionResponse(92, "PROVIDE_LEDGERENTRY"),
				new ActionResponse(93, "PROVIDE_LEDGERACCOUNTS"),

//				----------------from markets-------------------
				new ActionResponse(94, "CREATE_MARKETOBJECT"), new ActionResponse(95, "PROVIDE_DATAPROVIDERS"),
				new ActionResponse(96, "PROVIDE_MARKETOBJECTS"),
				new ActionResponse(97, "PROVIDE_MARKETOBJECTS_HISTORICAL_LAST"),
				new ActionResponse(98, "PROVIDE_MARKETOBJECTS_HISTORICAL_LAST_WITHTIMESTAMP"),
				new ActionResponse(99, "PROVIDE_MARKETOBJECTS_HISTORICAL_FROM_TO_LAST"),
				new ActionResponse(100, "EDIT_MARKETOBJECTS"), new ActionResponse(101, "DELETE_MARKETOBJECTS"),

//				-------------from chart of accounts------------------
				new ActionResponse(102, "CREATE_CHARTOFACCOUNTS"), new ActionResponse(103, "UPDATE_CHARTOFACCOUNTS"),
				new ActionResponse(104, "PROVIDE_CHARTOFACCOUNTS"), new ActionResponse(105, "DELETE_CHARTOFACCOUNTS"),
				new ActionResponse(106, "COMPUTE_PNL_STATEMENT")

		);
	}

	public static Map<Integer, ActionResponse> actionResponseMap() {
		Map<Integer, ActionResponse> map = new LinkedHashMap<>();
		for (ActionResponse actionResponse : actionslist()) {
			map.put(actionResponse.getId(), actionResponse);
		}
		return map;
	}
}
