package com.tps.zull.ZullServer.services;

import java.util.UUID;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tps.zull.ZullServer.Entity.UserProfiles;


@Transactional
@Repository("UserProfilesRepository")
public interface UserProfilesRepository extends JpaRepository<UserProfiles, UUID> {

}
