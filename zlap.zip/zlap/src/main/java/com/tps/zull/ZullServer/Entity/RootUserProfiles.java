package com.tps.zull.ZullServer.Entity;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class RootUserProfiles {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
	private UUID rootUserProfileID;
	@Type(type = "UserDetailsTemplateDataUserType")
	@Column(name = "rootUserProfile")
	private Map<String, Object> rootUserProfile = new LinkedHashMap<>(0);
	private String visibility;
	@OneToOne(mappedBy = "rootUserProfiles", cascade = { CascadeType.ALL })
	private RootUserMeta rootUserMeta;

	public UUID getRootUserProfileID() {
		return rootUserProfileID;
	}

	public void setRootUserProfileID(UUID rootUserProfileID) {
		this.rootUserProfileID = rootUserProfileID;
	}

	public Map<String, Object> getRootUserProfile() {
		return rootUserProfile;
	}

	public void setRootUserProfile(Map<String, Object> rootUserProfile) {
		this.rootUserProfile = rootUserProfile;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public RootUserMeta getRootUserMeta() {
		return rootUserMeta;
	}

	public void setRootUserMeta(RootUserMeta rootUserMeta) {
		this.rootUserMeta = rootUserMeta;
	}

	public RootUserProfiles(Map<String, Object> rootUserProfile, String visibility) {
		super();
		this.rootUserProfile = rootUserProfile;
		this.visibility = visibility;
	}

	public RootUserProfiles() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "RootUserProfiles [rootUserProfileID=" + rootUserProfileID + ", rootUserProfile=" + rootUserProfile
				+ ", visibility=" + visibility + ", ]";
	}

}
