package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "user_group_meta")
public class UserGroupMeta implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int groupID;
	private String groupName;
	private int parentGroup;
	private String recordCreatorID;
	private String rootUserID;
	@OneToMany(mappedBy = "userGroupMeta", cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	private Set<UserGroupRoles> userRolGroupRoles = new HashSet<UserGroupRoles>(0);

	public UserGroupMeta() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserGroupMeta(String groupName, int parentGroup, String ownerID, String rootUserID) {
		super();
		this.groupName = groupName;
		this.parentGroup = parentGroup;
		this.recordCreatorID = ownerID;
		this.rootUserID = rootUserID;
	}

	public String getRootUserID() {
		return rootUserID;
	}

	public void setRootUserID(String rootUserID) {
		this.rootUserID = rootUserID;
	}

	public int getGroupID() {
		return groupID;
	}

	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public int getParentGroup() {
		return parentGroup;
	}

	public void setParentGroup(int parentGroup) {
		this.parentGroup = parentGroup;
	}

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public Set<UserGroupRoles> getUserRolGroupRoles() {
		return userRolGroupRoles;
	}

	public void setUserRolGroupRoles(Set<UserGroupRoles> userRolGroupRoles) {
		this.userRolGroupRoles = userRolGroupRoles;
	}

	@Override
	public String toString() {
		return "UserGroupMeta [groupID=" + groupID + ", groupName=" + groupName + ", parentGroup=" + parentGroup
				+ ", ownerID=" + recordCreatorID + ", userRolGroupRoles=" + userRolGroupRoles + "]";
	}

}
