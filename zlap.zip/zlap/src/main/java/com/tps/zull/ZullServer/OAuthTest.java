package com.tps.zull.ZullServer;

import org.json.JSONException;

import com.google.common.base.Function;
import com.tps.zull.ZullServer.OAuth.UpdatableBCrypt;

public class OAuthTest {

	public static void main(String[] args) throws JSONException {
		System.out.println(hash("reader1234"));

		// PasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(8);
		// System.out.println(bCryptPasswordEncoder.encode("reader1234"));
		// System.out.println(BCrypt.hashpw("reader1234", BCrypt.gensalt(4)));
//		$2a$08$gznbisdK8P0RyUbPfm7eEOTy258bzurxrBKCZj3oWAjq2pF7j1GBi

		// public static boolean verifyAndUpdateHash(String password, String hash,
		// Function<String, Boolean> updateFunc) {

		// $2a$08$dwYz8O.qtUXboGosJFsS4u19LHKW7aCQ0LXXuNlRfjjGKwj5NfKSe
		// RestTemplate restTemplate = new RestTemplate();
		// String plainCreds =
		// "spring-security-oauth2-read-write-client:spring-security-oauth2-read-write-client-password1234";
		// byte[] plainCredsBytes = plainCreds.getBytes();
		// byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		// String base64Creds = new String(base64CredsBytes);
		// HttpHeaders headers = new HttpHeaders();
		// headers.add("Authorization", "Basic " + base64Creds);
		// MultiValueMap<String, String> request = new LinkedMultiValueMap<String,
		// String>();
		// request.add("grant_type", "password");
		// request.add("username", "Ravi");
		// request.add("password", "reader1234");
		// request.add("client_id", "spring-security-oauth2-read-write-client");
		// request.add("Authorization", "Basic " + base64Creds);
		// headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		// HttpEntity<MultiValueMap<String, String>> entity = new
		// HttpEntity<MultiValueMap<String, String>>(request,
		// headers);
		// ResponseEntity<String> loginResponse =
		// restTemplate.exchange("http://localhost:5050/oauth/token",
		// HttpMethod.POST, entity, String.class);
		// JSONObject userJson = new JSONObject(loginResponse.getBody());
		// System.out.println(restTemplate.getForEntity(
		// "http://localhost:7080/ariadne/tps/api/groups?access_token=" +
		// userJson.getString("access_token"),
		// String.class));

	}

	private static final UpdatableBCrypt bcrypt = new UpdatableBCrypt(8);

	public static String hash(String password) {
		return bcrypt.hash(password);
	}

	public static boolean verifyAndUpdateHash(String password, String hash, Function<String, Boolean> updateFunc) {
		return bcrypt.verifyAndUpdateHash(password, hash, updateFunc);
	}
}
