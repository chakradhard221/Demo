package com.tps.zull.ZullServer.services;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tps.zull.ZullServer.Entity.RootUserMeta;

@Service
@Transactional
public interface RootUserMetaRepository extends JpaRepository<RootUserMeta, UUID> {

	public List<RootUserMeta> findByUserName(String username);

}
