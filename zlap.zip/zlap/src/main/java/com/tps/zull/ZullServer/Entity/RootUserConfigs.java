package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;

@Entity
public class RootUserConfigs implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	@OneToOne
	@JoinColumn(name = "rootUserID")
	private RootUserMeta rootUserMeta;
	@Type(type = "UserDetailsTemplateDataUserType")
	private Map<String, Object> userConfigs = new LinkedHashMap<>(0);

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public RootUserMeta getRootUserMeta() {
		return rootUserMeta;
	}

	public void setRootUserMeta(RootUserMeta rootUserMeta) {
		this.rootUserMeta = rootUserMeta;
	}

	public Map<String, Object> getUserConfigs() {
		return userConfigs;
	}

	public void setUserConfigs(Map<String, Object> userConfigs) {
		this.userConfigs = userConfigs;
	}

	public RootUserConfigs(RootUserMeta rootUserMeta, Map<String, Object> userConfigs) {
		super();
		this.rootUserMeta = rootUserMeta;
		this.userConfigs = userConfigs;
	}

	@Override
	public String toString() {
		return "RootUserConfigs [Id=" + Id + ", userConfigs=" + userConfigs + "]";
	}

	public RootUserConfigs() {
		super();
		// TODO Auto-generated constructor stub
	}

}
