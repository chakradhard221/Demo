package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
// @Table(name = "UserRole")
public class UserRole implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	private int permissionID;
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "userRoleID", nullable = false)
	private UserRoleMeta userRoleMeta;
	private String recordCreatorID;

	public UserRole() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRole(int permissionID, UserRoleMeta userRoleMeta, String recordCreatorID) {
		super();
		this.permissionID = permissionID;
		this.userRoleMeta = userRoleMeta;
		this.recordCreatorID = recordCreatorID;
	}

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getPermissionID() {
		return permissionID;
	}

	public void setPermissionID(int permissionID) {
		this.permissionID = permissionID;
	}

	public UserRoleMeta getUserRoleMeta() {
		return userRoleMeta;
	}

	public void setUserRoleMeta(UserRoleMeta userRoleMeta) {
		this.userRoleMeta = userRoleMeta;

	}

	@Override
	public String toString() {
		return "UserRoleAttachedActions [Id=" + Id + ", permissionID=" + permissionID + "]";
	}

}
