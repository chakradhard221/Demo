package com.tps.zull.ZullServer;

import java.net.URISyntaxException;
import java.security.Principal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tps.zull.ZullServer.Entity.UserMeta;
import com.tps.zull.ZullServer.services.UserMetaRepository;

/**
 * Created by Peter_Szanto on 4/21/2017.
 */
@RestController

public class UserController {

	@Autowired
	UserMetaRepository userMetaRepository;

	@PreAuthorize("hasAuthority('USER_WRITE')")
	@RequestMapping({ "/user", "/me" })
	public Principal user(OAuth2Authentication principal) {
		System.err.println("outh1");
		((OAuth2AuthenticationDetails) principal.getDetails()).getTokenType();
		((OAuth2AuthenticationDetails) principal.getDetails()).getTokenValue();
		return principal;
	}

	@PreAuthorize("hasAuthority('USER_WRITE')")
	@RequestMapping({ "/reader" })
	public String reader() {
		return "READER";
	}

	@PreAuthorize("hasAuthority('USER_WRITE')")
	@RequestMapping({ "/writer" })
	public String writer() {
		return "WRITER";
	}

	@PreAuthorize("hasAuthority('USER_UPDATE')")
	@RequestMapping("/")
	public String welcome(Map<String, Object> model) throws URISyntaxException {
		System.err.println("outh");
		return "home";
		// java.net.URI location = new java.net.URI("http://localhost:5055/#!/login/");
		// return Response.temporaryRedirect(location).build();
	}

	@GetMapping("/usermeta")
	public ResponseEntity<UserMeta> fasdfas() {

		UserMeta userMeta = userMetaRepository
				.findbyUserMetaByRootUserIDAndUserName("4adf70ea-0281-46a8-82cd-c0b59a2b8ece", "Ashwanth");
		if (userMeta == null) {
			System.out.println("CANt....");
		}

		System.out.println(userMeta);

		return null;

	}
}
