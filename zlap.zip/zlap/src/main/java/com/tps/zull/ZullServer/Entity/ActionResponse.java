package com.tps.zull.ZullServer.Entity;

public class ActionResponse {
	private int id;
	private String permissionName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	@Override
	public String toString() {
		return "ActionResponse [id=" + id + ", permissionName=" + permissionName + "]";
	}

	public ActionResponse(int id, String permissionName) {
		super();
		this.id = id;
		this.permissionName = permissionName;
	}

	public ActionResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

}
