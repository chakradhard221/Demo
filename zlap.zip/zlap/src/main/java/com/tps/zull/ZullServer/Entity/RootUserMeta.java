package com.tps.zull.ZullServer.Entity;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

//@Data
@Entity
@Table(name = "root_user_meta")
public class RootUserMeta {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "root_userid")
	private UUID rootUserID;
	@Column(name = "root_user_group")
	private long rootUserGroup;
	private String userName;
	private String password;
	@OneToOne
	@JoinColumn(name = "rootUserProfileID")
	private RootUserProfiles rootUserProfiles;
	@OneToOne(mappedBy = "rootUserMeta", cascade = { CascadeType.ALL })
	RootUserConfigs rootUserConfigs;

	public UUID getRootUserID() {
		return rootUserID;
	}

	public void setRootUserID(UUID rootUserID) {
		this.rootUserID = rootUserID;
	}

	public long getRootUserGroup() {
		return rootUserGroup;
	}

	public void setRootUserGroup(long rootUserGroup) {
		this.rootUserGroup = rootUserGroup;
	}

	public RootUserProfiles getRootUserProfiles() {
		return rootUserProfiles;
	}

	public void setRootUserProfiles(RootUserProfiles rootUserProfiles) {
		this.rootUserProfiles = rootUserProfiles;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	// public RootUserMeta(RootUserProfiles rootUserProfiles, long parentGroup) {
	// super();
	//
	// this.rootUserProfiles = rootUserProfiles;
	// this.rootUserGroup = parentGroup;
	// }

	public RootUserConfigs getRootUserConfigs() {
		return rootUserConfigs;
	}

	public void setRootUserConfigs(RootUserConfigs rootUserConfigs) {
		this.rootUserConfigs = rootUserConfigs;
	}

	public RootUserMeta(RootUserProfiles rootUserProfiles, long rootUserGroup, String userName, String password) {
		super();
		this.rootUserGroup = rootUserGroup;
		this.userName = userName;
		this.password = password;
		this.rootUserProfiles = rootUserProfiles;
	}

	public RootUserMeta() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "RootUserMeta [rootUserID=" + rootUserID + ",  rootUserGroup=" + rootUserGroup + ", rootUserProfiles="
				+ rootUserProfiles + "]";
	}

}
