package com.tps.zull.ZullServer.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "UserRoles")
public class UserRoles implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "role_id")
	private int roleID;

	private String recordCreatorID;
	// @Column(name = "user_id")
	// private String userID;

	@ManyToOne
	@JoinColumn(name = "roleUserID", nullable = false, referencedColumnName = "userid")
	private UserMeta userMeta;

	public UserRoles() {
		super();
	}

	public UserRoles(int roleID, String recordCreatorID, UserMeta userMeta) {
		super();
		this.roleID = roleID;
		this.recordCreatorID = recordCreatorID;
		this.userMeta = userMeta;
	}

	public String getRecordCreatorID() {
		return recordCreatorID;
	}

	public void setRecordCreatorID(String recordCreatorID) {
		this.recordCreatorID = recordCreatorID;
	}

	public UserMeta getUserMeta() {
		return userMeta;
	}

	public void setUserMeta(UserMeta userMeta) {
		this.userMeta = userMeta;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRoleID() {
		return roleID;
	}

	public void setRoleID(int roleID) {
		this.roleID = roleID;
	}

	@Override
	public String toString() {
		return "UserRoles [id=" + id + ", roleID=" + roleID + ", recordCreatorID=" + recordCreatorID + "]";
	}

}
