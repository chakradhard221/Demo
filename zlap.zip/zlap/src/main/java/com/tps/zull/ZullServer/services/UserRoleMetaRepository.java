package com.tps.zull.ZullServer.services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tps.zull.ZullServer.Entity.UserRoleMeta;

@Transactional
@Service
public interface UserRoleMetaRepository extends JpaRepository<UserRoleMeta, Integer> {

}
