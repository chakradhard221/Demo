package com.tps.zull.ZullServer.Entity;

//public class UserDetailsOAuth implements Serializable, org.springframework.security.core.userdetails.UserDetails {
public class UserDetailsOAuth {/*
	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private boolean isAccountNonExpired;
	private boolean isCredentialsNonExpired;
	private boolean isAccountNonLocked;
	private boolean isEnabled;
	private Collection<Authority> authorities;

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return this.authorities;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return this.userName;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return this.isAccountNonExpired;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return this.isAccountNonLocked;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return this.isCredentialsNonExpired;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return this.isEnabled;
	}

	public UserDetailsOAuth(String userName, String password, boolean isAccountNonExpired,
			boolean isCredentialsNonExpired, boolean isAccountNonLocked, boolean isEnabled,
			Collection<Authority> authorities) {
		super();
		this.userName = userName;
		this.password = password;
		this.isAccountNonExpired = isAccountNonExpired;
		this.isCredentialsNonExpired = isCredentialsNonExpired;
		this.isAccountNonLocked = isAccountNonLocked;
		this.isEnabled = isEnabled;
		this.authorities = authorities;
	}

	@Override
	public String toString() {
		return "UserDetailsOAuth [userName=" + userName + ", password=" + password + ", isAccountNonExpired="
				+ isAccountNonExpired + ", isCredentialsNonExpired=" + isCredentialsNonExpired + ", isAccountNonLocked="
				+ isAccountNonLocked + ", isEnabled=" + isEnabled + ", authorities=" + authorities + "]";
	}

*/}
