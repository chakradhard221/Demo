package com.tps.fileupload;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FileuploadControlller {
	final String Source_Folder = "/home/aswindia-23/Desktop/";

	@PostMapping("data")
	public String dataUpload(@RequestParam("data") MultipartFile data) throws IOException {

		byte[] bytes = data.getBytes();
		Path path = Paths.get(Source_Folder + data.getOriginalFilename());
		Files.write(path, bytes);
		return "datagot Stored";
	}

	@PostMapping("read")
	public String readDataFromOffice() throws InvalidPasswordException, IOException {
		System.out.println("..enter...");
		PDDocument load = PDDocument.load(new File("/home/aswindia-23/Desktop/123.pdf"));
		if (!load.isEncrypted()) {
			System.out.println("..if..enter...");
			 PDFTextStripperByArea stripper = new PDFTextStripperByArea();
             stripper.setSortByPosition(true);
             PDFTextStripper tStripper = new PDFTextStripper();
             String pdfFileInText = tStripper.getText(load);
             System.out.println("Text:" + pdfFileInText);
             String lines[] = pdfFileInText.split("\\r?\\n");
             for (String line : lines) {
            	 
                 System.out.println(line);
             }
		}

		return "Data Read";

	}

}
