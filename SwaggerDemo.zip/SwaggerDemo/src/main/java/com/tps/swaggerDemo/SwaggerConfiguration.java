package com.tps.swaggerDemo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;
//@Component
//@Primary
//@EnableAutoConfiguration
public class SwaggerConfiguration implements SwaggerResourcesProvider {

	@Override
	public List<SwaggerResource> get() {
		// TODO Auto-generated method stub
		ArrayList<SwaggerResource> swagger = new ArrayList<SwaggerResource>();
		SwaggerResource swaggerResource = new SwaggerResource();
		swaggerResource.setName("TPS-ABS");
//		swaggerResource.setUrl("/mySwagger");
		swaggerResource.setSwaggerVersion("1.0.0");
		swagger.add(swaggerResource);
		return swagger;
	}

	 
	
}
