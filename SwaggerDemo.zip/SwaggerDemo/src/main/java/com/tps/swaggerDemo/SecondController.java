package com.tps.swaggerDemo;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecondController {

	@PostMapping("second")
	public String opp() {
		System.out.println("....secondControllerOpp...");
		return "Second cnotroller opp";
	}

}
