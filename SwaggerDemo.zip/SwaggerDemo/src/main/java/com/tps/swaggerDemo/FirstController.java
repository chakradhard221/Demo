package com.tps.swaggerDemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@RestController
@Api(value="Employee Management System")
public class FirstController {
	@GetMapping("/get")
	public String demo() {
	return "..dataGet...122";
	}
	
}
