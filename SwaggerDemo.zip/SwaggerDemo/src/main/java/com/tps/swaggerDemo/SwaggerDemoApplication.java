package com.tps.swaggerDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
//@EnableZuulProxy
public class SwaggerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerDemoApplication.class, args);
	}
	
//	@Bean
//	UiConfiguration uiConfig() {
//		return new UiConfiguration("validatorURL", "list", "alpha", "schema", UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS,false,true,10000L);
//				
//	}
}
