package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class FirstController {
	
	@Value(value = "${reqUrl}")
	private String reqUrl;
	
	@Autowired
	private RestTemplate template;
	@GetMapping("/first")
	public String getIt() {
		System.out.println("...first...");
//		RestTemplate restTemplate = new RestTemplate();
		String forObject = template.getForObject(reqUrl, String.class);
		System.out.println("..forObject..."+forObject);
		return "...firstSWorked..";
	}
//	@GetMapping("/login")
//	public String login() {
//		RestTemplate restTemplate = new RestTemplate();
//		System.out.println("...userUrl..."+userUrl);
//		String url=userUrl+"?userDetails=mff,mff";
//		String string = restTemplate.getForObject(url, String.class);
//		return string;
//	}
}
