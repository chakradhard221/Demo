package com.example.demo;

import java.io.InputStream;
import java.security.KeyStore;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication

public class SslServiceOneApplication {
//	@Autowired(required = true)
//	CloseableHttpClient httpClient;

	public static void main(String[] args) {
		SpringApplication.run(SslServiceOneApplication.class, args);
	}

//	@Bean
//	public RestTemplate restTemplate() {
//
//		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
//		return restTemplate;
//
//	}

//	@Bean
//	public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory() {
//		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
//		clientHttpRequestFactory.setHttpClient(httpClient);
//		return clientHttpRequestFactory;
//	}


	@SuppressWarnings("deprecation")
	@Bean
	public RestTemplate getRestTemplate() {

		RestTemplate restTemplate = new RestTemplate();

		KeyStore keyStore;
		HttpComponentsClientHttpRequestFactory requestFactory = null;
		try {
//			/Zull-Server/src/main/resources/solitxSsl.jks
			keyStore = KeyStore.getInstance("jks");
			ClassPathResource resource = new ClassPathResource("newcertificate.jks");
			InputStream inputStream = resource.getInputStream();
			keyStore.load(inputStream, "aswindia".toCharArray());

			SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
					new SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy())
							.loadKeyMaterial(keyStore, "aswindia".toCharArray()).build(),
					NoopHostnameVerifier.INSTANCE);

			
//			new SSLConnectionSocketFactory(null,new org.apache.http.ssl.SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy());)
			CloseableHttpClient build = HttpClients.custom().setSSLSocketFactory(socketFactory)
					.build();
			requestFactory = new HttpComponentsClientHttpRequestFactory(build);
//		  requestFactory.setHttpClient(build);
			restTemplate.setRequestFactory(requestFactory);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(".........Exeception....");
			e.printStackTrace();
		}
		return restTemplate;

	}

}
