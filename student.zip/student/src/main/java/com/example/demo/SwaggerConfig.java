package com.example.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.BasicAuth;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

@Configuration
@Primary
public class SwaggerConfig  {
	@Bean
	public Docket doIt() {
		ArrayList<SecurityScheme> schema = new ArrayList<SecurityScheme>();
		schema.add(new BasicAuth("basicAuth"));
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.example.demo")).paths(PathSelectors.regex("/.*")).build().securitySchemes(schema);
	}

//	@Override
//	public List<SwaggerResource> get() {
//		SwaggerResource swaggerResource = new SwaggerResource();
//		swaggerResource.setLocation("http://localhost:3200/v2/api-docs");
//		swaggerResource.setName("StudentService");
//		return Collections.singletonList(swaggerResource);
//	}

}
