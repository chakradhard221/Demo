package com.example.demo;

public class StringDemoWithName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(".....dataGet...");

		String s = "chakradhar";

	}

}
