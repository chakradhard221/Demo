package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;

@RestController
public class StudentController {
	@GetMapping("/get")
	@ApiOperation(value = "getStudentData", authorizations = { @Authorization(value = "basicAuth") })
	public String dataGet() {
		return "dataRetrived...";
	}

	@PostMapping("/postStudent")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "access_token", value = "Authorization token", paramType = "query", dataType = "string") })
	public String godata() {
		return "dataStored";
	}

}
